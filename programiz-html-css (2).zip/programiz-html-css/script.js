document.addEventListener('DOMContentLoaded', () => {
  const createProjectForm = document.getElementById('create-project-form');
  const projectsList = document.getElementById('projects-list');
  const createProjectLink = document.getElementById('create-project-link');
  const viewProjectsLink = document.getElementById('view-projects-link');
  const createProjectSection = document.getElementById('create-project-section');
  const projectsSection = document.getElementById('projects-section');

  createProjectLink.addEventListener('click', () => {
    createProjectSection.style.display = 'block';
    projectsSection.style.display = 'none';
  });

  viewProjectsLink.addEventListener('click', () => {
    createProjectSection.style.display = 'none';
    projectsSection.style.display = 'block';
    fetchProjects();
  });

  createProjectForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('project-name').value;
    const description = document.getElementById('project-description').value;
    
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, description }),
    });
    
    if (response.ok) {
      alert('Project created successfully!');
      createProjectForm.reset();
    } else {
      alert('Failed to create project.');
    }
  });

  async function fetchProjects() {
    const response = await fetch('/api/projects');
    const projects = await response.json();
    projectsList.innerHTML = '';
    projects.forEach(project => {
      const projectDiv = document.createElement('div');
      projectDiv.className = 'project';
      projectDiv.innerHTML = `
        <h3>${project.name}</h3>
        <p>${project.description}</p>
      `;
      projectsList.appendChild(projectDiv);
    });
  }
});
